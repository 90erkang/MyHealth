package com.myhealth.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.time.*;
import java.util.*;

@Service
public class GoogleHealthService {

    @Value("${google.client-id}") private String clientId;
    @Value("${google.client-secret}") private String clientSecret;
    @Value("${google.redirect-uri}") private String redirectUri;

    public Map<String, Object> getTodayHealthData(String code) {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, Object> finalResult = new HashMap<>();
        finalResult.put("steps", 0);
        finalResult.put("distance", 0.0);
        finalResult.put("heartRate", 0);
        finalResult.put("temp", 0.0);
        finalResult.put("oxygen", 0);
        finalResult.put("stepsKcal", 0);     // ✅ 걸음 소모 칼로리
        finalResult.put("walkMinutes", 0);   // ✅ 환산 운동 시간(분)

        try {
            // 1. 토큰 발급
            String tokenUrl = "https://oauth2.googleapis.com/token";
            Map<String, String> tokenParams = Map.of(
                    "code", code,
                    "client_id", clientId,
                    "client_secret", clientSecret,
                    "redirect_uri", redirectUri,
                    "grant_type", "authorization_code"
            );
            Map<String, Object> tokenRes = restTemplate.postForObject(tokenUrl, tokenParams, Map.class);
            String accessToken = (String) tokenRes.get("access_token");

            // 2. ✅ 오늘 하루 기준: 오늘 00:00:00 ~ 현재
            ZoneId zone    = ZoneId.of("Asia/Seoul");
            long endTime   = Instant.now().toEpochMilli();
            long startTime = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli();

            // 3. 요청 (오늘 하루를 버킷 1개로)
            Map<String, Object> requestBody = Map.of(
                    "aggregateBy", List.of(
                            Map.of("dataTypeName", "com.google.step_count.delta"),
                            Map.of("dataTypeName", "com.google.distance.delta"),
                            Map.of("dataTypeName", "com.google.heart_rate.bpm")
                    ),
                    "bucketByTime", Map.of("durationMillis", endTime - startTime),
                    "startTimeMillis", startTime,
                    "endTimeMillis", endTime
            );

            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(accessToken);
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            ResponseEntity<Map> response = restTemplate.postForEntity(
                    "https://www.googleapis.com/fitness/v1/users/me/dataset:aggregate", entity, Map.class
            );

            if (response.getBody() != null) {
                List<Map<String, Object>> buckets = (List<Map<String, Object>>) response.getBody().get("bucket");
                if (buckets != null && !buckets.isEmpty()) {
                    List<Map<String, Object>> datasets = (List<Map<String, Object>>) buckets.get(0).get("dataset");
                    Object stepsObj    = extractVal(datasets, 0);
                    Object distanceObj = extractVal(datasets, 1);
                    Object heartObj    = extractVal(datasets, 2);

                    finalResult.put("steps",     stepsObj);
                    finalResult.put("distance",  distanceObj);
                    finalResult.put("heartRate", heartObj);

                    // ✅ 걸음수 → 운동 시간 + 칼로리 환산
                    int steps = stepsObj instanceof Number ? ((Number) stepsObj).intValue() : 0;
                    double distanceM = distanceObj instanceof Number ? ((Number) distanceObj).doubleValue() : 0.0;
                    double distanceKm = distanceM / 1000.0;

                    int walkMinutes = steps > 0 ? Math.round(steps / 100.0f) : 0;
                    int kcalByMet   = (int) Math.round(3.5 * 65 * (walkMinutes / 60.0));
                    int kcalByDist  = (int) Math.round(distanceKm * 60);
                    int stepsKcal   = distanceKm > 0 ? Math.max(kcalByDist, kcalByMet) : kcalByMet;

                    finalResult.put("walkMinutes", walkMinutes);
                    finalResult.put("stepsKcal",   stepsKcal);
                }
            }
        } catch (Exception e) {
            System.err.println("❌ 데이터 연동 중 오류 발생: " + e.getMessage());
        }
        return finalResult;
    }

    private Object extractVal(List<Map<String, Object>> datasets, int index) {
        try {
            List<Map<String, Object>> points = (List<Map<String, Object>>) datasets.get(index).get("point");
            if (points == null || points.isEmpty()) return 0;
            List<Map<String, Object>> values = (List<Map<String, Object>>) points.get(0).get("value");
            Map<String, Object> valMap = values.get(0);
            return valMap.containsKey("intVal") ? valMap.get("intVal") : valMap.get("fpVal");
        } catch (Exception e) { return 0; }
    }
}