package com.myhealth.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Value("${app.frontend-url}")
    private String frontendUrl;

    public void sendPasswordResetEmail(String toEmail, String token) {
        String resetLink = frontendUrl + "/reset-pw?token=" + token;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(fromEmail);
        message.setTo(toEmail);
        message.setSubject("[MyHealth] 비밀번호 재설정 안내");
        message.setText(
                "안녕하세요, MyHealth입니다.\n\n" +
                "아래 링크를 클릭하여 비밀번호를 재설정해 주세요.\n" +
                "링크는 30분 동안만 유효합니다.\n\n" +
                resetLink + "\n\n" +
                "본인이 요청하지 않으셨다면 이 메일을 무시하셔도 됩니다."
        );

        mailSender.send(message);
    }
}
