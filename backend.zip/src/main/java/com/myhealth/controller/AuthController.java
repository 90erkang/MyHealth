package com.myhealth.controller;

import com.myhealth.entity.PasswordResetToken;
import com.myhealth.entity.User;
import com.myhealth.repository.PasswordResetTokenRepository;
import com.myhealth.repository.UserRepository;
import com.myhealth.security.JwtUtil;
import com.myhealth.service.EmailService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final EmailService emailService;
    private final PasswordResetTokenRepository tokenRepository;

    /**
     * POST /api/auth/login
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User req) {
        User found = userRepository.findByUsername(req.getUsername());
        if (found == null || !found.getPassword().equals(req.getPassword())) {
            return ResponseEntity.status(401).body(Map.of("message", "아이디 또는 비밀번호가 틀렸습니다."));
        }
        String token = jwtUtil.generateToken(found.getUsername(), found.getRole());
        return ResponseEntity.ok(Map.of(
                "token",    token,
                "id",       found.getId(),
                "username", found.getUsername(),
                "email",    found.getEmail(),
                "role",     found.getRole()
        ));
    }

    /**
     * POST /api/auth/signup
     */
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody User req) {
        if (userRepository.existsByUsername(req.getUsername())) {
            return ResponseEntity.badRequest().body(Map.of("message", "이미 사용 중인 아이디입니다."));
        }
        if (userRepository.existsByEmail(req.getEmail())) {
            return ResponseEntity.badRequest().body(Map.of("message", "이미 사용 중인 이메일입니다."));
        }
        if (req.getRole() == null || req.getRole().isBlank()) {
            req.setRole("USER");
        }
        userRepository.save(req);
        return ResponseEntity.ok(Map.of("message", "회원가입이 완료되었습니다."));
    }

    /**
     * POST /api/auth/find-pw
     * Body: { "email": "..." }
     * → 재설정 링크를 이메일로 발송
     */
    @Transactional
    @PostMapping("/find-pw")
    public ResponseEntity<?> findPw(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return ResponseEntity.status(404).body(Map.of("message", "해당 이메일로 가입된 정보가 없습니다."));
        }

        // 기존 토큰 삭제 후 새 토큰 발급
        tokenRepository.deleteByUser(user);

        PasswordResetToken resetToken = new PasswordResetToken();
        resetToken.setUser(user);
        resetToken.setToken(UUID.randomUUID().toString());
        resetToken.setExpiresAt(LocalDateTime.now().plusMinutes(30));
        tokenRepository.save(resetToken);

        // 이메일 발송
        emailService.sendPasswordResetEmail(email, resetToken.getToken());

        return ResponseEntity.ok(Map.of("message", "비밀번호 재설정 링크를 전송했습니다."));
    }

    /**
     * POST /api/auth/reset-pw
     * Body: { "token": "...", "newPassword": "..." }
     * → 토큰 검증 후 비밀번호 변경
     */
    @Transactional
    @PostMapping("/reset-pw")
    public ResponseEntity<?> resetPw(@RequestBody Map<String, String> body) {
        String tokenValue = body.get("token");
        String newPassword = body.get("newPassword");

        PasswordResetToken resetToken = tokenRepository.findByToken(tokenValue)
                .orElse(null);

        if (resetToken == null || resetToken.isUsed()) {
            return ResponseEntity.status(400).body(Map.of("message", "유효하지 않은 링크입니다."));
        }
        if (resetToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            return ResponseEntity.status(400).body(Map.of("message", "링크가 만료되었습니다. 다시 요청해 주세요."));
        }

        // 비밀번호 변경 & 토큰 사용 처리
        User user = resetToken.getUser();
        user.setPassword(newPassword);
        userRepository.save(user);

        resetToken.setUsed(true);
        tokenRepository.save(resetToken);

        return ResponseEntity.ok(Map.of("message", "비밀번호가 성공적으로 변경되었습니다."));
    }
}