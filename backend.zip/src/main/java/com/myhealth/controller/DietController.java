package com.myhealth.controller;

import com.myhealth.entity.DietLog;
import com.myhealth.repository.DietRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

/**
 * ✅ 식단 API - /api/diet/**
 *
 * GET  /api/diet/search?query=...              공공 식품 영양성분 DB 검색
 * GET  /api/diet/{username}?year=&month=       월간 식단 조회
 * GET  /api/diet/{username}/day?date=          일별 식단 조회
 * POST /api/diet/{username}                    날짜 식단 저장 (전체 교체)
 * DEL  /api/diet/{username}?date=              날짜 식단 삭제
 */
@RestController
@RequestMapping("/api/diet")
@RequiredArgsConstructor
public class DietController {

    private final DietRepository dietRepository;

    private static final String SERVICE_KEY =
        "c35a7bc960f15f7576e7cbe6c1bb010bd94ece7b1c18950f40525c57a205e163";
    private static final String FOOD_API_URL =
        "https://apis.data.go.kr/1471000/FoodNtrCpntDbInfo02/getFoodNtrCpntDbInq02";

    // ══════════════════════════════════════════════════════
    // 공공 식품 영양성분 DB 검색 (프록시)
    // ══════════════════════════════════════════════════════

    @GetMapping("/search")
    public ResponseEntity<String> searchFood(
            @RequestParam String query,
            @RequestParam(defaultValue = "1")  int pageNo,
            @RequestParam(defaultValue = "20") int numOfRows
    ) {
        try {
            String encodedKey   = URLEncoder.encode(SERVICE_KEY, StandardCharsets.UTF_8);
            String encodedQuery = URLEncoder.encode(query.trim(), StandardCharsets.UTF_8);

            String urlStr = FOOD_API_URL
                    + "?serviceKey=" + encodedKey
                    + "&FOOD_NM_KR=" + encodedQuery
                    + "&pageNo="     + pageNo
                    + "&numOfRows="  + numOfRows
                    + "&type=json";

            URI uri = new java.net.URL(urlStr).toURI();
            System.out.println("[DietController] 식품 API 호출: " + uri);

            RestTemplate restTemplate = new RestTemplate();
            String response = restTemplate.getForObject(uri, String.class);

            if (response == null) {
                return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                        .body("{\"error\":\"공공데이터 API 응답 없음\"}");
            }
            return ResponseEntity.ok(response);

        } catch (HttpServerErrorException | HttpClientErrorException e) {
            return ResponseEntity.status(e.getStatusCode()).body(e.getResponseBodyAsString());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError()
                    .body("{\"error\":\"서버 에러: " + e.getMessage() + "\"}");
        }
    }

    // ══════════════════════════════════════════════════════
    // 식단 CRUD
    // ══════════════════════════════════════════════════════

    /** 월간 식단 조회 */
    @GetMapping("/{username}")
    public ResponseEntity<List<DietLog>> getMonthlyDiet(
            @PathVariable String username,
            @RequestParam int year,
            @RequestParam int month
    ) {
        LocalDate start = YearMonth.of(year, month).atDay(1);
        LocalDate end   = YearMonth.of(year, month).atEndOfMonth();
        return ResponseEntity.ok(dietRepository.findByUsernameAndDateBetween(username, start, end));
    }

    /** 일별 식단 조회 */
    @GetMapping("/{username}/day")
    public ResponseEntity<List<DietLog>> getDailyDiet(
            @PathVariable String username,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        return ResponseEntity.ok(dietRepository.findByUsernameAndDate(username, date));
    }

    /**
     * 날짜 식단 저장 (전체 교체 방식)
     * Body: { "date": "2026-02-20", "meals": [ { mealType, menu, weight, kcal, ... } ] }
     */
    @PostMapping("/{username}")
    @Transactional
    public ResponseEntity<List<DietLog>> saveDiet(
            @PathVariable String username,
            @RequestBody DietSaveRequest request
    ) {
        LocalDate date = request.getDate();
        // 기존 날짜 데이터 전부 삭제 후 재저장
        dietRepository.deleteByUsernameAndDate(username, date);

        List<DietLog> toSave = request.getMeals().stream()
                .filter(m -> m.getMenu() != null && !m.getMenu().isBlank())
                .map(m -> {
                    DietLog log = new DietLog();
                    log.setUsername(username);
                    log.setDate(date);
                    log.setMealType(m.getMealType());
                    log.setMenu(m.getMenu());
                    log.setBaseWeight(m.getBaseWeight());
                    log.setWeight(m.getWeight());
                    log.setKcal(m.getKcal());
                    log.setCarbs(m.getCarbs());
                    log.setProtein(m.getProtein());
                    log.setFat(m.getFat());
                    return log;
                }).toList();

        return ResponseEntity.ok(dietRepository.saveAll(toSave));
    }

    /** 날짜 식단 삭제 */
    @DeleteMapping("/{username}")
    @Transactional
    public ResponseEntity<Void> deleteDiet(
            @PathVariable String username,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date
    ) {
        dietRepository.deleteByUsernameAndDate(username, date);
        return ResponseEntity.noContent().build();
    }

    // ── DTO ──────────────────────────────────────────────
    @lombok.Data
    public static class DietSaveRequest {
        private LocalDate date;
        private List<MealItem> meals;
    }

    @lombok.Data
    public static class MealItem {
        private String mealType;
        private String menu;
        private Double baseWeight;
        private Double weight;
        private Double kcal;
        private Double carbs;
        private Double protein;
        private Double fat;
    }

}
