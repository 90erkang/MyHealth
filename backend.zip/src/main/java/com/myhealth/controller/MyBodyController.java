package com.myhealth.controller;

import com.myhealth.entity.HealthRecord;
import com.myhealth.repository.HealthRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * ✅ 건강 기록 API - /api/health/**
 * @CrossOrigin 제거 → CorsConfig에서 전역 처리
 */
@RestController
@RequestMapping("/api/health")
@RequiredArgsConstructor
public class MyBodyController {

    private final HealthRepository healthRepository;

    /** 전체 기록 조회 */
    @GetMapping("/{username}")
    public List<HealthRecord> getMyRecords(@PathVariable String username) {
        return healthRepository.findAllByUsernameOrderByDateAsc(username);
    }

    /** 기록 저장/수정 (upsert) */
    @PostMapping("/save")
    public HealthRecord saveRecord(@RequestBody HealthRecord record) {
        HealthRecord existing = healthRepository
                .findByUsernameAndDate(record.getUsername(), record.getDate())
                .orElse(null);

        if (existing != null) {
            existing.setWeight(record.getWeight());
            existing.setHeight(record.getHeight());
            existing.setSystolicBp(record.getSystolicBp());
            existing.setDiastolicBp(record.getDiastolicBp());
            existing.setBloodSugar(record.getBloodSugar());
            return healthRepository.save(existing);
        }
        return healthRepository.save(record);
    }

    /** 기록 삭제 */
    @DeleteMapping("/{username}/{date}")
    public void deleteRecord(@PathVariable String username, @PathVariable String date) {
        LocalDate localDate = LocalDate.parse(date);
        healthRepository.findByUsernameAndDate(username, localDate)
                .ifPresent(healthRepository::delete);
    }
}
