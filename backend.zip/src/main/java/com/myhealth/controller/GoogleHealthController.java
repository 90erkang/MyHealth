package com.myhealth.controller;

import com.myhealth.service.GoogleHealthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/sync")
@CrossOrigin(origins = "http://localhost:3000")
public class GoogleHealthController {

    @Autowired
    private GoogleHealthService googleHealthService;

    @PostMapping("/google-fit")
    public ResponseEntity<?> syncGoogleFit(@RequestBody Map<String, String> request) {
        String code = request.get("code");
        try {
            // ✅ Map<String, Object>로 받아서 Integer와 Double을 모두 수용함
            Map<String, Object> healthData = googleHealthService.getTodayHealthData(code);
            return ResponseEntity.ok(healthData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("동기화 실패: " + e.getMessage());
        }
    }
}