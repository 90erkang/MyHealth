package com.myhealth.controller;

import com.myhealth.entity.GameStats;
import com.myhealth.repository.GameRepository;
import com.myhealth.repository.DietRepository;
import com.myhealth.repository.RoutineRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/game")
@RequiredArgsConstructor // ✅ 생성자 주입 방식 사용
@CrossOrigin(origins = "*")
public class GameController {

    private final GameRepository gameRepository;
    private final DietRepository dietRepository;
    private final RoutineRepository routineRepository;

    @GetMapping("/{username}")
    public GameStats getStats(@PathVariable String username) {
        return gameRepository.findByUsername(username)
                .orElseGet(() -> {
                    GameStats newEntity = new GameStats();
                    newEntity.setUsername(username);
                    newEntity.setLevel(1);
                    newEntity.setXp(0);
                    newEntity.setStr(10);
                    newEntity.setHp(100);
                    newEntity.setMaxHp(100);
                    newEntity.setTitle("헬린이");
                    return gameRepository.save(newEntity);
                });
    }

    @PostMapping("/save")
    public GameStats saveStats(@RequestBody GameStats stats) {
        GameStats existing = gameRepository.findByUsername(stats.getUsername())
                .orElse(new GameStats());

        existing.setUsername(stats.getUsername());
        existing.setLevel(stats.getLevel());
        existing.setXp(stats.getXp());
        existing.setStr(stats.getStr());
        existing.setHp(stats.getHp());
        existing.setMaxHp(stats.getMaxHp());
        existing.setTitle(stats.getTitle());
        existing.setLastExpDate(stats.getLastExpDate());

        return gameRepository.save(existing);
    }

    @GetMapping("/daily-summary/{username}")
    public Map<String, Object> getDailySummary(@PathVariable String username) {
        LocalDate today = LocalDate.now();

        // ✅ DietRepository에서 오늘의 섭취 칼로리 합계 조회
        Double eaten = dietRepository.sumCaloriesByUsernameAndDate(username, today);

        // ✅ RoutineRepository에서 오늘의 소모 칼로리 합계 조회
        // 메서드명은 RoutineRepository.java에 정의된 이름과 100% 일치해야 합니다.
        Integer burnedInt = routineRepository.sumCaloriesByUsernameAndDate(username, today);
        Double burned = (burnedInt != null) ? burnedInt.doubleValue() : 0.0;

        // ✅ RoutineRepository에서 오늘의 총 운동 시간(분) 합산
        Integer burnedMinutes = routineRepository.sumTimeByUsernameAndDate(username, today);
        if (burnedMinutes == null) burnedMinutes = 0;

        GameStats stats = gameRepository.findByUsername(username).orElse(new GameStats());
        boolean isExpGainedToday = today.equals(stats.getLastExpDate());

        Map<String, Object> summary = new HashMap<>();
        summary.put("eaten", eaten != null ? eaten : 0.0);
        summary.put("burned", burned);
        summary.put("burnedMinutes", burnedMinutes);
        summary.put("isExpGainedToday", isExpGainedToday);

        return summary;
    }
}