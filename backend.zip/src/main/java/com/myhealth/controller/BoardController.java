package com.myhealth.controller;

import com.myhealth.entity.Board;
import com.myhealth.entity.BoardComment;
import com.myhealth.repository.BoardCommentRepository;
import com.myhealth.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * ✅ 게시판 API - /api/board/**
 * @CrossOrigin 제거 → CorsConfig에서 전역 처리
 * 공지 작성 시 ADMIN 권한 서버사이드 검증 추가
 */
@RestController
@RequestMapping("/api/board")
@RequiredArgsConstructor
public class BoardController {

    private final BoardRepository boardRepository;
    private final BoardCommentRepository commentRepository;

    /** 게시글 목록 조회 (페이징 + 검색) */
    @GetMapping
    public ResponseEntity<Page<Board>> getBoards(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "") String keyword
    ) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Board> result = keyword.isBlank()
                ? boardRepository.findAllByOrderByNoticeDescCreatedAtDesc(pageable)
                : boardRepository.findByTitleContainingOrderByNoticeDescCreatedAtDesc(keyword, pageable);
        return ResponseEntity.ok(result);
    }

    /** 게시글 상세 조회 (조회수 증가) */
    @GetMapping("/{id}")
    public ResponseEntity<Board> getBoard(@PathVariable Long id) {
        return boardRepository.findById(id).map(board -> {
            board.setViews(board.getViews() + 1);
            boardRepository.save(board);
            return ResponseEntity.ok(board);
        }).orElse(ResponseEntity.notFound().build());
    }

    /** 게시글 작성 */
    @PostMapping
    public ResponseEntity<Board> createBoard(
            @RequestBody Board board,
            Authentication auth  // JWT에서 추출된 인증 정보
    ) {
        board.setViews(0);

        // ✅ 공지 작성은 서버에서도 ADMIN만 허용
        if (Boolean.TRUE.equals(board.getNotice())) {
            boolean isAdmin = auth != null && auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
            if (!isAdmin) {
                board.setNotice(false); // 권한 없으면 일반 글로 강제 전환
            }
        }
        return ResponseEntity.ok(boardRepository.save(board));
    }

    /** 게시글 수정 */
    @PutMapping("/{id}")
    public ResponseEntity<Board> updateBoard(
            @PathVariable Long id,
            @RequestBody Board updated,
            Authentication auth
    ) {
        return boardRepository.findById(id).map(board -> {
            board.setTitle(updated.getTitle());
            board.setContent(updated.getContent());

            // 공지 여부도 ADMIN만 변경 가능
            boolean isAdmin = auth != null && auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
            if (isAdmin) {
                board.setNotice(updated.getNotice());
            }
            return ResponseEntity.ok(boardRepository.save(board));
        }).orElse(ResponseEntity.notFound().build());
    }

    /** 게시글 삭제 */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBoard(@PathVariable Long id) {
        commentRepository.deleteByBoardId(id);
        boardRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // ── 댓글 ──────────────────────────────────────────────

    /** 댓글 목록 */
    @GetMapping("/{id}/comments")
    public ResponseEntity<List<BoardComment>> getComments(@PathVariable Long id) {
        return ResponseEntity.ok(commentRepository.findByBoardIdOrderByCreatedAtAsc(id));
    }

    /** 댓글 작성 */
    @PostMapping("/{id}/comments")
    public ResponseEntity<BoardComment> addComment(
            @PathVariable Long id,
            @RequestBody BoardComment comment
    ) {
        comment.setBoardId(id);
        return ResponseEntity.ok(commentRepository.save(comment));
    }

    /** 댓글 삭제 */
    @DeleteMapping("/comments/{commentId}")
    public ResponseEntity<Void> deleteComment(@PathVariable Long commentId) {
        commentRepository.deleteById(commentId);
        return ResponseEntity.noContent().build();
    }
}
