package com.myhealth.controller;

import com.myhealth.entity.Routine;
import com.myhealth.repository.RoutineRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/routine")
@RequiredArgsConstructor
public class RoutineController {

    private final RoutineRepository routineRepository;
    private static final String SERVICE_KEY = "c35a7bc960f15f7576e7cbe6c1bb010bd94ece7b1c18950f40525c57a205e163";
    private static final String MET_API_URL = "https://api.odcloud.kr/api/15068730/v1/uddi:ed8fd49d-2724-4acc-a62e-f655a9e9a96e";

    @GetMapping("/search")
    public ResponseEntity<Map<String, Object>> searchRoutineExercise(@RequestParam String query) {
        try {
            // ✅ DietController 스타일로 인코딩 적용
            String urlStr = MET_API_URL
                    + "?page=1&perPage=1000&returnType=JSON"
                    + "&serviceKey=" + SERVICE_KEY; // ODCloud는 보통 키 인코딩 없이 사용하지만 에러방지용

            URI uri = new URI(urlStr);
            RestTemplate restTemplate = new RestTemplate();

            @SuppressWarnings("unchecked")
            Map<String, Object> apiResponse = restTemplate.getForObject(uri, Map.class);

            if (apiResponse == null || !apiResponse.containsKey("data")) {
                return ResponseEntity.ok(new HashMap<>());
            }

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> rawData = (List<Map<String, Object>>) apiResponse.get("data");

            // ✅ 검색어 필터링 및 데이터 정규화 (영상 정보 제외, 이름/MET만)
            List<Map<String, Object>> filtered = rawData.stream()
                    .filter(item -> String.valueOf(item.get("운동명")).contains(query))
                    .map(item -> {
                        Map<String, Object> m = new HashMap<>();
                        m.put("trng_nm", item.get("운동명"));
                        m.put("met_value", item.get("단위체중당에너지소비량"));
                        return m;
                    }).collect(Collectors.toList());

            // ✅ Routine.jsx가 기다리는 { response: { body: { items: { item: [] } } } } 구조
            Map<String, Object> itemWrap = Collections.singletonMap("item", filtered);
            Map<String, Object> bodyWrap = new HashMap<>();
            bodyWrap.put("items", itemWrap);
            bodyWrap.put("totalCount", filtered.size());

            Map<String, Object> responseWrap = Collections.singletonMap("body", bodyWrap);
            return ResponseEntity.ok(Collections.singletonMap("response", responseWrap));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/{username}")
    public ResponseEntity<List<Routine>> getMonthlyRoutine(@PathVariable String username, @RequestParam int year, @RequestParam int month) {
        LocalDate start = YearMonth.of(year, month).atDay(1);
        LocalDate end = YearMonth.of(year, month).atEndOfMonth();
        return ResponseEntity.ok(routineRepository.findByUsernameAndWorkoutDateBetween(username, start, end));
    }

    @PostMapping("/{username}")
    @Transactional
    public ResponseEntity<List<Routine>> saveRoutine(@PathVariable String username, @RequestBody RoutineSaveRequest request) {
        routineRepository.deleteByUsernameAndWorkoutDate(username, request.getDate());
        List<Routine> toSave = request.getWorkouts().stream()
                .map(w -> Routine.builder()
                        .username(username)
                        .workoutDate(request.getDate())
                        .name(w.getName())
                        .met(w.getMet())
                        .time(w.getTime())
                        .kcal(w.getKcal())
                        .build()).toList();
        return ResponseEntity.ok(routineRepository.saveAll(toSave));
    }

    @lombok.Data
    public static class RoutineSaveRequest {
        private LocalDate date;
        private List<WorkoutItem> workouts;
    }

    @lombok.Data
    public static class WorkoutItem {
        private String name;
        private Double met;
        private Integer time;
        private Integer kcal;
    }
}