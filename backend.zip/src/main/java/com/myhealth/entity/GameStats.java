package com.myhealth.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "fitness_game_stats")
public class GameStats {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    private Integer level = 1;
    private Integer xp = 0;
    private Integer str = 0;
    private Integer hp = 100;
    private Integer maxHp = 100;
    private String title = "헬린이";
    private LocalDate lastExpDate = LocalDate.of(1900, 1, 1);
}